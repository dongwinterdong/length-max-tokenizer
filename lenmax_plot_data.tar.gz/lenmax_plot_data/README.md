# Length-MAX 绘图数据说明

本数据包包含生成 `lenmax_advantage_summary.png` 等图表所需的所有原始 CSV 数据。

## 文件列表与用途

| 文件名 | 对应图表 | 描述 |
|--------|---------|------|
| `summary_lenmax_..._v048.csv` | **Figure 1A / 1.5** | 包含 Length-MAX 和 SuperBPE 在 WT103 上的最佳 Checkpoint 结果 (BPC, TPC)。 |
| `summary_lenmax_..._v042.csv` | **Figure 1A / 1.5** | 包含 BPE (Baseline) 的最佳 Checkpoint 结果。 |
| `downstream_threeway_results_v1.csv` | **Figure 1B** | 下游任务 (LAMBADA) 的准确率数据。 |
| `longctx_fair_results_v3.csv` | **Figure 1C** | 长上下文大海捞针 (Needle in a Haystack) 测试结果。 |
| `lenmax_token_distribution_wt103_valid.csv` | **Figure 1D / 2** | Tokenizer 在验证集上的词频分布统计（长尾、熵）。 |

---

## 指标解读指南

以下是各文件中关键列名的含义，以及**数值好坏的方向**：

### 1. 语言模型与压缩率 (LM Points)
*来源: summary_*.csv*

*   **`tpc` (Tokens Per Char)**: 每字符对应的 Token 数。
    *   ⬇️ **越低越好** (表示压缩率更高，同样文本用的 Token 更少)。
*   **`chars_per_token` (计算得出: 1/tpc)**: 每个 Token 平均代表的字符数。
    *   ⬆️ **越高越好** (同上，压缩率更高)。
*   **`bpc` (Bits Per Char)**: 每字符比特数，衡量模型预测能力的指标。
    *   ⬇️ **越低越好** (表示模型更聪明，困惑度更低)。
*   **`eval_loss`**: 验证集上的 Loss。
    *   ⬇️ **越低越好**。

### 2. 下游任务 (Downstream)
*来源: downstream_threeway_results_v1.csv*

*   **`acc` (Accuracy)**: 准确率 (0.0 - 1.0)。
    *   ⬆️ **越高越好**。

### 3. 长上下文 (Long Context / Needle)
*来源: longctx_fair_results_v3.csv*

*   **`acc`**: 大海捞针任务的检索准确率。
    *   ⬆️ **越高越好**。
*   **`needle_present_rate` (Retained)**: 针 (Passkey) 在经过 Tokenizer 处理和截断后是否还保留在上下文中。
    *   ⬆️ **越高越好** (越接近 1.0 表示没有因为 Token 耗尽而被截断丢失)。
*   **`trunc_rate`**: 截断率。
    *   ⬇️ **越低越好**。

### 4. 词表分布 (Token Distribution)
*来源: lenmax_token_distribution_wt103_valid.csv*

*   **`entropy_bits_per_token`**: Token 使用分布的熵。
    *   ⬇️ **越低越好** (在本文语境下)。较低的熵意味着分布更"尖锐" (sharper)，即模型可以更确定地预测下一个词，通常对应更高效的词表设计。
*   **`rare_types_f1` (freq=1)**: 在验证集中只出现过 1 次的 Token 类型数量。
    *   ⬇️ **越低越好**。长尾越少，说明词表中浪费的 slot 越少，词表利用率越高。
*   **`rare_types_le10` (freq<=10)**: 在验证集中出现次数 ≤10 的 Token 类型数量。
    *   ⬇️ **越低越好**。

## 脚本运行方式

如果你想使用这些文件重新画图，请运行：

```bash
python3 plot_lenmax_favorable_metrics.py \
    --len_vs_super_csv summary_lenmax_punctnorm_nostage_crossmix_v047_vs_superbpe_pack4000_evalval_steps10000_v048.csv \
    --bpe_baseline_csv summary_lenmax_punctwhitelist_stage30000_maxw3_pack4000_evalval_steps10000_v042.csv \
    --downstream_csv downstream_threeway_results_v1.csv \
    --longctx_csv longctx_fair_results_v3.csv \
    --dist_csv_in lenmax_token_distribution_wt103_valid.csv \
    --out_dir ./output_plots
```


